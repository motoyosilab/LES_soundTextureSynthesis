%% NOTE
% To run LES_soundSynth_main.m,
% "Sound Texture Synthesis Toolbox" by McDermott & Simoncelli is required. 
% Please obtain it from the following URL 
% and place it under the folder "LES_soundSynthesis".
%
% https://mcdermottlab.mit.edu/Sound_Texture_Synthesis_Toolbox_v1.7.zip

%% EXAMPLE 1
[orig,sr] = audioread('sounds/applause.wav');
[Stats, Synth] = LES_soundSynth(orig, sr);
audiowrite('outputs/LES_applause.wav', Synth.lePRsound, sr);

%% EXAMPLE 2
[orig,sr] = audioread('sounds/pouring_liquid.wav');
[Stats, Synth] = LES_soundSynth(orig, sr);
audiowrite('outputs/LES_pouring_liquid.wav', Synth.lePRsound, sr);

%% EXAMPLE 3
[orig,sr] = audioread('sounds/toothbrushing.wav');
[Stats, Synth] = LES_soundSynth(orig, sr);
audiowrite('outputs/LES_toothbrushing.wav', Synth.lePRsound, sr);