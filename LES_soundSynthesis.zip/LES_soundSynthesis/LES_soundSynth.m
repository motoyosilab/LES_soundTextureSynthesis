function [Stats, Synth] = LES_soundSynth(orig, sr)
%-----------------------------------------------------
% [Stats, Synth] = LES_soundSynth(orig, sr)
%
% computes linear(1st) and energy(2nd) spectrum of an original sound texture
% and synthesizes a new sound with the same spectra.
%
% orig : original sound texture
% sr   : sampling rate of the original sound
%
% Stats: struct of the computed spectra
% Synth: struct of the synthesized sounds
%
%
% NOTE:
% To run this code, "Sound Texture Synthesis Toolbox" 
% by McDermott & Simoncelli is required. Please obtain it 
% from the following URL and place it under the folder "LES_soundSynthesis".
%
% https://mcdermottlab.mit.edu/Sound_Texture_Synthesis_Toolbox_v1.7.zip
%

% This code is an instantiation of sound texture synthesis based on
% a two-stage spectral model and described in this paper:
%
% Maruyama, H. Okada, K. & Motoyoshi, I. (2023) 
% A two-stage spectral model for 
% sound texture perception : synthesis and psychophysics.
%
% Jan 2023 -- Hironori Maruyama, Kosuke Okada & Isamu Motoyoshi
%-----------------------------------------------------
%% parameters
envSR         = 400;        % sampling rate of an envelope [Hz]
beta          = 0.3;        % compression coefficient of envelope (env.^beta)
Nband         = 30;         % num of subbands
lowF          = 20;         % lower bound of center frequency [Hz]
highF         = 10000;      % upper bound of center frequency [Hz]

%% preparing
if exist('Sound_Texture_Synthesis_Toolbox','dir')==0
    error(['To run this code, "Sound Texture Synthesis Toolbox" by McDermott & Simoncelli is required. '...
           'Please obtain it from the following URL and place it under the folder "LES_soundSynthesis".  ',...
           'https://mcdermottlab.mit.edu/Sound_Texture_Synthesis_Toolbox_v1.7.zip'])
end
addpath('Sound_Texture_Synthesis_Toolbox');

Lorig = length(orig);
seed  = randn(Lorig,1);
% apply the window for fft
win   = sum(make_windows_rcos_flat_no_ends(Lorig, round(Lorig/sr), 0.5),2);
orig  = orig.*win;
seed  = seed.*win;
% make filter bank for decompose subbands and envelopes
[fl, ~] = make_erb_cos_filters(Lorig, sr, Nband, lowF, highF);

%% computes linear & energy spectra
[~,VE,~] = decompose_subbands(orig, fl, sr, envSR);

if beta ~= 0
    VE = VE.^beta;
end

ds_factor = round(sr/envSR);
Spect1    = abs(fftshift(fft(orig))); 
Spect2    = abs(fftshift(fft2(VE)));

Stats.SR             = sr;
Stats.DS             = ds_factor;
Stats.range_FiltFreq = [lowF, highF];
Stats.Spect1         = Spect1;
Stats.Spect2         = Spect2;

%% synthesizes a new sound
% linear spectrum randamization
ph1 = angle(fftshift(fft(seed)));
lPR  = real(ifft(ifftshift(Spect1.*(cos(ph1) + 1i.*sin(ph1)))));

% energy spectrum randamization
[~,nVE,nph_e2r] = decompose_subbands(lPR, fl, sr, envSR);
if beta ~= 0
    nVE = nVE.^beta;
end
ph2 = angle(fftshift(fft2(nVE)));       
nVE = real(ifft2(ifftshift(Spect2.*(cos(ph2) + 1i.*sin(ph2)))));  
if beta ~= 0
    nVE(nVE<0)=0;
    nVE = nVE.^(1/beta);
end
nVR = reconstruct_subbands(nVE,nph_e2r,ds_factor);
lePR = sum(nVR,2);

Synth.lPRsound = lPR;
Synth.lePRsound = lePR;                 

end

%%
function [subbands,envs,phase] = decompose_subbands(sound, fl, audioFs, envFs)
%--------------------------------------------------------------------------
% Filter a sound to obtain linear subbands (real part), envelopes, and phases
%
%  sound   : input sound
%  fl      : filter bank
%  audioFs : sampling rate of an input sound [Hz]
%  envFs   : sampling rate of an envelope [Hz] (envFs < audioFs)
%
%  subbands  : linear subbands (real part)
%  envs      : envelopes
%  phase     : phases (arg(cos + i sin))
%--------------------------------------------------------------------------
subbands = generate_subbands(sound, fl);
Hilsubbands = hilbert(subbands);
envs  = abs(Hilsubbands);
phase = angle(Hilsubbands);
ds_factor = round(audioFs/envFs);
envs = resample(envs,1,ds_factor);
envs(envs<0) = 0;

end

%%
function subbands = reconstruct_subbands(envs,phase,ds_factor)
%--------------------------------------------------------------------------
% Reconstruct the real part of linear subbands from envelope and phase
%
%  envs      : envelopes
%  phase     : phases (arg(cos + i sin))
%  ds_factor : downsampling factor of an envelope
%  envFs     : sampling rate of an envelope [Hz] (envFs < audioFs)
%
%  subbands  : linear subbands (real part)
%--------------------------------------------------------------------------

envs = resample(envs,ds_factor,1);
envs(envs<0)=0;
Nenvs  = length(envs);
Nphase = length(phase);
if Nenvs <= Nphase
    subbands = cos(phase(1:Nenvs,:)).*envs;
else
    subbands = cos(phase).*envs(1:Nphase,:);
end

end