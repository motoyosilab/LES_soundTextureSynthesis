MATAB code for a two-stage spectral model of sound textures - User Notes

This folder 'LES_soundSynthesis' contains a Matlab implementation of the sound texture synthesis algorithm described in this paper: 

Maruyama, H. Okada, K. & Motoyoshi, I. (2022) A two-stage spectral model for sound texture perception : synthesis and psychophysics.

These files have been reconfigured to make them more user-friendly. However, they should be functionally equivalent to those used to generate the stimuli in this paper. 

The code is set up to use the filter function provided by Josh McDermott, which is available on his web site: https://mcdermottlab.mit.edu/Sound_Texture_Synthesis_Toolbox_v1.7.zip

The basic synthesis process measures statistics in a given sound file, then alters a noise signal so that it has the measured statistics.

In order to try out the synthesis, please run the EXAMPLE in demoLES.m.

Hironori Maruyama, Kosuke Okada & Isamu Motoyoshi Jan 2023